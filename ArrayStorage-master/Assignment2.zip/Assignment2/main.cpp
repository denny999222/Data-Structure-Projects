#include <iostream>
#include <sequence1.h>
#include <sequence_test.cpp>
#include <sequence_exam.cpp>

int main() {
    // You can run the test code from here by importing the `sequence_test.cpp` and `sequence_exam.cpp` files
    // and using their functions.
    std::cout << "Hello, World!" << std::endl;
    return EXIT_SUCCESS;
}